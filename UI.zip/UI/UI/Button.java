package UI;
import javax.swing.*;
import java.awt.*;
public class Button extends JButton
{{
    
this.setPreferredSize(new Dimension(30,28)); 
this.setFocusable(false);
this.setBackground(Color.green);
this.setForeground(Color.white);
this.setFont(new Font("Times New Roman",Font.ITALIC,13 ));
this.setText("Buy Now");
}}