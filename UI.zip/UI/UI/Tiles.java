package UI;
import javax.swing.*;
import java.awt.*;
public class Tiles extends JPanel{ {
   Button b = new Button();
    this.setPreferredSize(new Dimension(150,150));
    this.setBackground(Color.black);
    this.setLayout(new BorderLayout());
    this.add(b, BorderLayout.PAGE_END);
    
}}
