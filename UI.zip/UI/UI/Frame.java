
package UI;
import java.awt.*;
import javax.swing.*;

public class Frame extends JFrame{
    Tiles t[] = new Tiles[6];
    Button b = new Button();
    JLabel audi,bmw,book,bike,computer,cycle,tab ;
    JButton cart;
    JPanel top,bottom,left,center;
    Frame()
    {   
        ImageIcon img_audi = new ImageIcon("audi.png");
        audi = new JLabel(img_audi );
        // audi.setIcon(img_audi);
        t[0].setLayout(new BorderLayout());
        t[0].add(audi, BorderLayout.PAGE_START);
        JTextField audi_text = new JTextField("Audi A8  for sale");
        t[0].add(audi_text,BorderLayout.PAGE_END);
        ImageIcon img = new ImageIcon("cart.png");
        cart = new JButton();
        cart.setIcon(img);
        this.setLayout(new BorderLayout(40,20));
        top = new JPanel();
        top.setPreferredSize(new Dimension(500,50));
        top.setBackground(Color.pink);

        bottom = new JPanel();
        bottom.setPreferredSize(new Dimension(500,50));
        bottom.setBackground(Color.blue);
       
        left = new JPanel();
        left.setBackground(Color.RED);
        left.setPreferredSize(new Dimension(50,500));

        center = new JPanel();
        center.setPreferredSize(new Dimension(200,200));
        center.setLayout(new GridLayout(2,3,20,20));
        for(int i=0;i<6;i++)
        {
            t[i] = new Tiles();
            
        }
        t[0].add(audi);
        center.add(t[0]);
        center.add(t[1]);
        center.add(t[2]);
        center.add(t[3]);
        center.add(t[4]);
        center.add(t[5]);
        left.add(cart);

    // this.add(b);
    this.add(center,BorderLayout.CENTER);
    this.add(top,BorderLayout.NORTH);
    this.add(bottom,BorderLayout.SOUTH);
    this.add(left,BorderLayout.WEST);
    
    this.setSize(900,900);
    // this.setLayout(new BorderLayout());
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);
    }
    
    public static void main(String[] args) {
        new Frame();
    }

}
